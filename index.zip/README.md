# Waights Garden Care

Static site for Waights Garden Care (Canterbury, UK)

Deployed automatically via GitHub Pages.
- **Main branch:** published live at https://aknak-ops.github.io/waights-garden-care
- **Workflow:** .github/workflows/deploy.yml
- **Build:** plain HTML + CSS + JS (no framework)
